/* eslint-disable import/no-extraneous-dependencies */
import '@storybook/addon-knobs/register';
import '@storybook/addon-backgrounds/register';
/* eslint-enable */
